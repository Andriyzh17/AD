package ejercicio1;

import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;

public class main7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		Scanner teclado = new Scanner(System.in);
				
		
	 int numero;
	 String dire;
	 String ext;
	 int ya;
	 
	 ArrayList<Filtro> filtros = new ArrayList<>();
	 
	 System.out.println("Dime el directorio");
	 dire = teclado.next();
	 
	 
	 do {
		 System.out.println("Dime la extenesiones");
		 ext = teclado.next();
		 filtros.add(new Filtro(ext));
		 System.out.println("1.Si quieres poner otro filtro, 2 si quieres acabar");
		 ya = teclado.nextInt();
	 }while(ya == 1);
	 
	 File fichero = new File(dire);
	 for (Filtro filtro : filtros) {
		 for (File filtro2 : fichero.listFiles()) {
			if(filtro.accept(filtro2)) {
				System.out.println(filtro2.getName());
			}
		}
	}
	}

}
