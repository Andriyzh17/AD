package ejercicio1;

import java.io.File;
import java.util.Scanner;

public class main {

	
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner teclado = new Scanner(System.in);
		
		System.out.println("Dime un directorio");
		String di = teclado.next();
		
		File directorio = new File(di);
		
		System.out.println("Directorio: " + directorio);
		

	}
	
	

}
