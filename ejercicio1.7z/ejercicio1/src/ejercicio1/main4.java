package ejercicio1;

import java.io.File;
import java.util.Scanner;

public class main4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner teclado = new Scanner(System.in);
		
		System.out.println("Dime un directorio");
		String di = teclado.next();
		
		
		File file = new File(di);
		if(file.exists()==true) {
			System.out.println("El directorio existe y fran me come los huevos");
		}else {
			System.out.println("No existe");
		}
		
	}

}
