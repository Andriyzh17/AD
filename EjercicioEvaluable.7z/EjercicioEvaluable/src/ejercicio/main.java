package ejercicio;

import java.io.File;
import java.util.Scanner;
import java.util.Date;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner teclado = new Scanner(System.in);
		
		
		System.out.println("Dime un directorio");
		String di = teclado.next();
		
		File file = new File(di);
		System.out.println("Que quieres hacer: ");
		System.out.println("1.-Toda la informacion.");
		System.out.println("2.-Crear carpeta.");
		System.out.println("3.-Crear fichero.");
		System.out.println("4.-Eliminar un fichero/carpeta.");
		System.out.println("5.-Renombrar un fichero/carpeta");
		int opcion = teclado.nextInt();
		
		
		
		switch (opcion) {
		case 1:
			getInformacion(di);
			break;
			
		case 2:
			crearCarpeta(di);
			break;

		case 3:
			
			break;
		case 4:
			
			break;
		case 5:
	
	break;

		default:
			System.out.println("Seleccione un numero que este entre ese rango");
			break;
		}
		
	}

	
	
	public static void getInformacion(String directorio) {
		
		File file = new File(directorio);
		
		
		String nombre = file.getName();
		System.out.println(nombre);
		
		String[] direc = file.list();
		File[] ficheros = file.listFiles();
		for (File filtros : ficheros) {
			System.out.println(direc);
		}
		
		String ruta = file.getAbsolutePath();
		System.out.println(ruta);
		
		Date d = new Date(file.lastModified());
		System.out.println("La ultima modificacion fue: " + d.getDay() +"/"+ d.getMonth() +"/" +d.getYear());
		
		boolean oculto = file.isHidden();
		
		
		if(oculto == true) {
			System.out.println("El archivo es oculto");
		}else {
		System.out.println("El archivo no es oculto");
		}
		
		
		if(file.exists()) {
			for (File filtros : ficheros) {		
		long bytes = file.length();
		System.out.println(filtros.getName()+"" + bytes + " bytes");
			}
		
		}
		
		
		
	}
	
	
	public static void crearCarpeta(String directorio) {
		Scanner teclado = new Scanner(System.in);
		
		File file = new File(directorio);
		
		System.out.println("Dime un nombre para la carpeta");
		String nombre = teclado.next();
		
		File n1 = new File(nombre);
		
		
		try {
			if(n1.mkdir()) {
				System.out.println("Se ha creado bien");
			}else {
				System.out.println("Ha habido un error");
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		
	}
}
