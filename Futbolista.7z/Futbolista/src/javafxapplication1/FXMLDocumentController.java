/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXML2.java to edit this template
 */
package javafxapplication1;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javax.xml.parsers.ParserConfigurationException;
import org.xml.sax.SAXException;

/**
 *
 * @author DAM2º
 */
public class FXMLDocumentController implements Initializable {
    
    private Label label;
    @FXML
    private TextField nombre;
    @FXML
    private Button siguiente;
    @FXML
    private Button atras;
    
    
    Integer position;
    
    ApoyoXML datos = new ApoyoXML();
    @FXML
    private TextField equipo;
    @FXML
    private TextField anyo;
    @FXML
    private TextField posicion;
    @FXML
    private TextField idField;
    @FXML
    private AnchorPane anchorpane;
    @FXML
    private void handlebotonAction(ActionEvent event) {
        System.out.println("You clicked me!");
        label.setText("Hello " + nombre.getText());
      
    }
      @FXML
    private void handleButtonActionNext(ActionEvent event) {
        position++;
        
        if(position==datos.registros()){
            idField.setText("");
            nombre.setText("");
            equipo.setText("");
            anyo.setText(""); 
            posicion.setText("");
        }
        else{
            datos.Read(position);
        }
    }

    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
         try {
            position = 0;
            datos.LeerXML("futbol.xml");
            
            Futbolista fut = new Futbolista();
            
            fut=datos.Read(0);
            idField.setText(String.valueOf(fut.getId()));
            nombre.setText(fut.getNombre());
            equipo.setText(fut.getEquipo());
            anyo.setText(String.valueOf(fut.getAnyo()));
             posicion.setText(fut.getPosicion());
            
        } catch (SAXException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ParserConfigurationException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }    
    
}
