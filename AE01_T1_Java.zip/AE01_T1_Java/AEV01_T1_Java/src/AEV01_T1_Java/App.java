package AEV01_T1_Java;

import java.util.ArrayList;
import java.util.Scanner;

public class App {

	Scanner teclado = new Scanner(System.in);
	
	
	
	public App() {
		;
	}

	
	public String sayHello() {
		
		String hola = "Hola mundo";
		
		return hola;
		
	}
	public String primos() {
		
		int numero1;
		int numero2;
		int resultado = 0;
		int numero3 = 0;
		String resultado2 = "El resultado es ";
		
		System.out.println("Dime un número");
		numero1 = teclado.nextInt();
		
		System.out.println("Dime otro número");
		numero2 = teclado.nextInt();
		
		for (int i = numero1; i < numero2; i++) {
			if(i % 2 == 0) {
				System.out.println(i + " no es primo");
			} else {
				System.out.println(i + " es primo");
			}
			numero3 = i + 0;
			resultado = numero3 + resultado ;
		}
		return resultado2 + resultado;
	}
	
	public String nombre(ArrayList<Integer> nu){
		String nombres = null;
		int numero1 = 0;
		int numero = 0;
		ArrayList<String> no = new ArrayList<>();
		no.add("Pablo");
		no.add("Fran");
		no.add("Antonio");
		no.add("Fermín");
		no.add("Gonazlo");
		no.add("Kike");
		
		for (int i = 0; i < no.size(); i++) {
			if(numero1 == 1) {
				no.get(i);
			}
		}
		
		
		return nombres;
		
	}
	

}


















