package AEV01_T1_Java;

import java.util.ArrayList;
import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner teclado = new Scanner(System.in);
		
		int numero1;
		int numero2;
		App ap = new App();
		ArrayList<Integer> nu = new ArrayList<>();
		System.out.println("Dime un numero del 1 al 3");
		System.out.println("1. Di hola");
		System.out.println("2. Números primos");
		System.out.println("3. Nombres");
		int opcion = teclado.nextInt();
		
		
		switch (opcion) {
		case 1:
			System.out.println(ap.sayHello());
			break;
		case 2:
			System.out.println(ap.primos());
			break;
		case 3:
			for (int i = 0; i < 6; i++) {
				System.out.println("Dime un numero: ");
				int numero3 = teclado.nextInt();
				nu.add(numero3);
			}
			System.out.println(ap.nombre(nu));
			break;

		default:
			break;
		}
		
		
		
	}

}
