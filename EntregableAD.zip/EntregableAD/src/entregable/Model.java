package entregable;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class Model {

	private String ruta = "C:\\Users\\DAM2\\eclipse-workspace\\EntregableAD\\texto.txt";
	private File file1 = new File(ruta);
	
	
	
	public Model(String rut) {
		this.ruta = rut;
		
	}

	
	public Model() {
		// TODO Auto-generated constructor stub
	}



	public ArrayList<String> readTexto() {
		
		ArrayList<String> lineas = new ArrayList<>();
		
		try {
	          
			FileReader re = new FileReader(file1);
			BufferedReader lector = new BufferedReader(re);
            String linea;

            while ((linea = lector.readLine()) != null) {
                lineas.add(linea);
     
            }
       } 
			catch (IOException e) {
           e.printStackTrace();
        }
		return lineas;
   }
	
	
	
	public int buscarTexto(String texto)  {
		int contador =0;
		  
		    
		    try (BufferedReader br = new BufferedReader(new FileReader(file1))) {
		        String linea;
		        String textoBuscado = texto.toLowerCase(); 
		        
		        while ((linea = br.readLine()) != null) {
		      
		            String[] palabras = linea.toLowerCase().split(" ");
		            
		          
		            for (String palabra : palabras) {
		                if (palabra.equals(textoBuscado)) {
		                    contador++;
		                }
		            }
		        }
		    } catch (FileNotFoundException e) {
		        e.printStackTrace();
		    } catch (IOException e) {
		        e.printStackTrace();
		    }

		    return contador;
		}
}
	
	
	
	
	
	
	


