package entregable;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.JOptionPane;

public class Controlador {
	
	private Vista vista;
	private Model modelo;

	 public Controlador(Model model, Vista vista) {
	        this.modelo = model;
	        this.vista = vista;
	        mostrarTexto();
	        buscarTexto();
	 }
	 public void mostrarTexto() {
			
			ArrayList<String> lineas = modelo.readTexto();
			String texto = String.join("\n", lineas);
			vista.getTextAreaOriginal().setText(texto);
			
	}
	 
	public void buscarTexto() {
		
			vista.getBtnBuscar().addActionListener(new ActionListener() {
				
			public void actionPerformed(ActionEvent arg0) {
			
				String palabrabuscada = vista.getTextFieldBuscar().getText();
				int contador = modelo.buscarTexto(palabrabuscada);
				JOptionPane.showMessageDialog(vista.getTextAreaOriginal(), "La palabra \"" + palabrabuscada + "\" aparece " + contador+ " veces");
			}
			});
}
}
