/**
 * 
 */
/**
 * 
 */
module EntregableAD {
	requires java.desktop;
}